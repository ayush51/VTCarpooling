credentials = {
	"database":"dc0b54dgnpkcdh",
	"user":"ufzefhqcvytwlz",
	"password":"092c56e06cddf0a1d0f7ab885c0801688c235107ac842c42fc724a97959274c5",
	"host":"ec2-174-129-236-147.compute-1.amazonaws.com",
	"port":"5432"
}